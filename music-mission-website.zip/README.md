# Music Mission

Music Mission is an educational platform to teach music theory, appreciation, composition, history, and performance. Includes account system and games.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Visit `http://localhost:3000` to explore the site.
